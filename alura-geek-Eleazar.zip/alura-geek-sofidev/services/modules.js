const d= document;
import toggleDarkMode from "../assets/controllers/dark-mode.js";
import botonTropper from "../assets/controllers/floating-menu.js";
import focusInput from "../assets/controllers/search.js"


